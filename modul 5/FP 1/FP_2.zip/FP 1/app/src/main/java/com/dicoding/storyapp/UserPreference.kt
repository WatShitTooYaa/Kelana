package com.dicoding.storyapp

import android.content.Context
import android.content.SharedPreferences

class UserPreference(context: Context) {
    companion object {
        private const val PREFS_NAME = "user_pref"
        private const val NAME = "name"
        private const val USER_ID = "user_id"
        private const val TOKEN = "token"
    }

    val preference: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun setUser(user: UserModel) {
        val editor = preference.edit()
        editor.putString(NAME, user.name)
        editor.putString(USER_ID, user.userId)
        editor.putString(TOKEN, user.token)
        editor.apply()
    }

    fun getUser() : UserModel {
        val model = UserModel()
        model.name = preference.getString(NAME, "")
        model.userId = preference.getString(USER_ID, "")
        model.token = preference.getString(TOKEN, "")

        return model
    }

    fun deleteUser() {
        val editor = preference.edit()
        editor.clear()
        editor.apply()
    }
}