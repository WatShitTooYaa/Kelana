package com.dicoding.storyapp.story.data

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.liveData
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.liveData
import com.dicoding.storyapp.BuildConfig
import com.dicoding.storyapp.data.paging.StoryPagingSource
import com.dicoding.storyapp.data.response.GetStoryResponse
import com.dicoding.storyapp.data.response.ListStoryItem
import com.dicoding.storyapp.data.retrofit.ApiService
import com.dicoding.storyapp.database.StoryDatabase
import com.dicoding.storyapp.data.Result
import kotlinx.coroutines.Dispatchers
import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.toRequestBody

class StoryRepository(private val storyDatabase: StoryDatabase, private val apiService: ApiService) {

    private var pagingSource: StoryPagingSource? = null
    fun getStory(): LiveData<PagingData<ListStoryItem>>{
        return Pager(
            config = PagingConfig(
                pageSize = 5
            ),
            pagingSourceFactory = {
                StoryPagingSource(apiService)
            }
        ).liveData
    }
//
//    suspend fun uploadStory(description: String, photo: MultipartBody.Part): Result<String> {
//        return try {
//            val response = apiService.postStory(
//                description.toRequestBody("text/plain".toMediaType()),
//                photo
//            )
//            if (response.message.isNotEmpty()) {
//                // Invalidate the paging source to reload data
//                pagingSource?.invalidate()
//                Result.Success(response.message)
//            } else {
//                Result.Error(response.message)
//            }
//        } catch (e: Exception) {
//            Result.Error(e.message ?: "An error occurred")
//        }
//    }

//    fun getStoryTesting(): LiveData<Result<List<ListStoryItem>>> {
//        return liveData(Dispatchers.IO) {
//            emit(Result.Loading)
//            try {
//                val response = apiService.getStoryAsync(1, 15)
//                val storyItem = response.listStory
//                val storyList = storyItem.map { story ->
//                    ListStoryItem(
//                        id = story.id,
//                        name = story.name,
//                        description = story.description,
//                        photoUrl = story.photoUrl,
//                        createdAt = story.createdAt,
//                        lon = story.lon,
//                        lat = story.lon
//                    )
//                }
//                emit(Result.Success(storyList))
//            } catch (e: Exception) {
//                Log.d("NewsRepository", "getHeadlineNews: ${e.message.toString()} ")
//                emit(Result.Error(e.message.toString()))
//            }
//        }
//    }

//    fun invalidatePagingSource() {
//        pagingSource?.invalidate()
//    }

    suspend fun getLocation(page: Int, size: Int) : GetStoryResponse {
        return apiService.getStoryAsync(page, size)
    }
}