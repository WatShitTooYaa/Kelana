package com.dicoding.storyapp.map

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import com.dicoding.storyapp.data.response.ListStoryItem
import com.dicoding.storyapp.story.data.StoryRepository

class MapsViewModel(context: Context, storyRepository: StoryRepository) : ViewModel() {
//    val _Location : LiveData<List<ListStoryItem>> = storyRepository.getLocation(1, 1)
    val locations = liveData {
        val response = storyRepository.getLocation(1, 20)
        emit(response)
    }
}