package com.dicoding.storyapp.widget

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.widget.RemoteViews
import android.widget.RemoteViewsService
import com.dicoding.storyapp.R
import com.dicoding.storyapp.UserModel
import com.dicoding.storyapp.UserPreference
import com.dicoding.storyapp.data.response.ListStoryItem
import com.dicoding.storyapp.data.retrofit.ApiConfig
import java.net.URL

internal class StackRemoteViewsFactory(private val mContext: Context) : RemoteViewsService.RemoteViewsFactory {

    private val mWidgetItems = ArrayList<Bitmap>()
    private var stories: List<ListStoryItem> = listOf()
    private lateinit var mUserPreference: UserPreference
    private lateinit var user: UserModel

    override fun onCreate() {
        // Initialization (not much needed here for now)
        mUserPreference = UserPreference(mContext)
        user = mUserPreference.getUser()
    }

    override fun onDataSetChanged() {
        // Fetch data from getAllStory and update mWidgetItems
        fetchStories()
    }

    override fun onDestroy() {
        // Clean up resources
        mWidgetItems.clear()
    }

    override fun getCount(): Int {
        return stories.size
    }

    override fun getViewAt(position: Int): RemoteViews {
        val rv = RemoteViews(mContext.packageName, R.layout.widget_item)

        val story = stories[position]
        val bitmap = getBitmapFromUrl(story.photoUrl)

        rv.setImageViewBitmap(R.id.imageView, bitmap)

        val fillInIntent = Intent()
        fillInIntent.putExtra(StoryWidget.EXTRA_ITEM, story.name)
        rv.setOnClickFillInIntent(R.id.imageView, fillInIntent)

        return rv
    }

    override fun getLoadingView(): RemoteViews? {
        return null
    }

    override fun getViewTypeCount(): Int {
        return 1
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun hasStableIds(): Boolean {
        return true
    }

    private fun fetchStories() {
        // Here you can use Retrofit or any other networking library to fetch the data
        // For the sake of simplicity, let's assume you have a synchronous call that fetches the data
        val client = ApiConfig.getStoryApiService(user.token ?: "").getStory().execute()
        if (client.isSuccessful) {
            stories = client.body()?.listStory ?: listOf()
            mWidgetItems.clear()
            for (story in stories) {
                val bitmap = getBitmapFromUrl(story.photoUrl)
                if (bitmap != null) {
                    mWidgetItems.add(bitmap)
                }
            }
        }
    }

    private fun getBitmapFromUrl(url: String): Bitmap? {
        return try {
            val inputStream = URL(url).openStream()
            BitmapFactory.decodeStream(inputStream)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}