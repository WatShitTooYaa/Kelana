package com.dicoding.storyapp.story.di

import android.content.Context
import com.dicoding.storyapp.data.retrofit.ApiConfig
import com.dicoding.storyapp.database.StoryDatabase
import com.dicoding.storyapp.story.data.StoryRepository

object Injection {
    fun provideRepository(context: Context, token: String): StoryRepository {
        val database = StoryDatabase.getDatabase(context)
        val apiService = ApiConfig.getStoryApiService(token)
        return StoryRepository(database, apiService)
    }
}