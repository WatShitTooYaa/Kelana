package com.dicoding.storyapp.story.di

import android.app.Application
import android.content.Context
import com.dicoding.storyapp.data.retrofit.ApiConfig
import com.dicoding.storyapp.database.StoryDatabase
import com.dicoding.storyapp.story.data.StoryRepository

object Injection {
    fun provideRepository(application: Application, token: String): StoryRepository {
        val database = StoryDatabase.getDatabase(application)
        val apiService = ApiConfig.getStoryApiService(token)
        return StoryRepository(database, apiService)
    }
}