package com.dicoding.storyapp.utils

import com.dicoding.storyapp.data.response.ListStoryItem


object DataDummy {
    fun generateDummyListStory(): List<ListStoryItem> {
        val newsList = ArrayList<ListStoryItem>()
        for (i in 0..10) {
            val news = ListStoryItem(
                id = "story-$i-fdXLAehbxMY2",
                name = "dummy",
                description = "desc",
                photoUrl = "https://story-api.dicoding.dev/images/stories/photos-1717422753139_ade697ffd3fb166e991e.jpg",
                createdAt = "2024-06-03T13:52:33.141Z",
                lat = 37.4220133 + (i / 10),
                lon = -122.0840581 - (i / 10)
            )
            newsList.add(news)
        }
        return newsList
    }


}