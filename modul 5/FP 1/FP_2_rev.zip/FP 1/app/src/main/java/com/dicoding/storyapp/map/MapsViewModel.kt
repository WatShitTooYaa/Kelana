package com.dicoding.storyapp.map

import android.app.Application
import android.content.Context
import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import com.dicoding.storyapp.UserModel
import com.dicoding.storyapp.UserPreference
import com.dicoding.storyapp.data.response.ListStoryItem
import com.dicoding.storyapp.story.data.StoryRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.dicoding.storyapp.data.Result
import com.dicoding.storyapp.data.response.GetStoryResponse
import com.dicoding.storyapp.data.retrofit.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MapsViewModel(private val storyRepository: StoryRepository, private val application: Application) : ViewModel() {
//    private lateinit var storyRepository: StoryRepository
    private var mUserPreference: UserPreference = UserPreference(application)
    private var user = UserModel()
    private var token: String? = null

    init {
        user = mUserPreference.getUser()
        token = user.token
        showToast(token ?: "token kosong")
        token?.let {
            getLoc(it)
        }
//        getLoc(token!!)
    }

    private var _location = MutableLiveData<List<ListStoryItem>>()
    val location: LiveData<List<ListStoryItem>> = _location

    private fun getLoc(token: String) {
//        val client = ApiConfig.getApiService().getStory()
        val client = storyRepository.getLocation(token)
        client.enqueue(object : Callback<GetStoryResponse> {
            override fun onResponse(
                call: Call<GetStoryResponse>,
                response: Response<GetStoryResponse>
            ) {
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    if (responseBody != null){
                        _location.value = responseBody.listStory
                    }
                    else {
                        showToast(response.message())
                    }
                }
            }

            override fun onFailure(call: Call<GetStoryResponse>, t: Throwable) {
                showToast("Fail when get")
            }
        })
    }

    private fun showToast(message: String) {
        Toast.makeText(application, message, Toast.LENGTH_SHORT).show()
    }
}