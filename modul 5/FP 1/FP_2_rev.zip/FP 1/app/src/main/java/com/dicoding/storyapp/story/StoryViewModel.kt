package com.dicoding.storyapp.story

import android.content.Context
import android.util.Log
import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.dicoding.storyapp.UserModel
import com.dicoding.storyapp.UserPreference
import com.dicoding.storyapp.data.response.GetStoryResponse
import com.dicoding.storyapp.data.response.ListStoryItem
import com.dicoding.storyapp.data.retrofit.ApiConfig
import com.dicoding.storyapp.story.data.StoryRepository
import kotlinx.coroutines.launch
import okhttp3.MultipartBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import com.dicoding.storyapp.data.Result
import kotlinx.coroutines.flow.collect

class StoryViewModel(storyRepository: StoryRepository) : ViewModel() {
//    private var mUserPreference: UserPreference = UserPreference(context)
//    private var user = mUserPreference.getUser()

//    private val _listStory = MutableLiveData<List<ListStoryItem>>()
//    var listStory: LiveData<List<ListStoryItem>> = _listStory
//
    private val _listStory = MutableLiveData<List<ListStoryItem>>()
    var listStory: LiveData<PagingData<ListStoryItem>> = storyRepository.getStory()

    private val _isLoading = MutableLiveData<Boolean>()
    var isLoading: LiveData<Boolean> = _isLoading



//    fun invalidateStories() {
//        storyRepository.invalidatePagingSource()
//    }

//    fun uploadStory(description: String, photo: MultipartBody.Part) {
//        viewModelScope.launch {
//            _isLoading.value = true
//            val result = storyRepository.uploadStory(description, photo)
//            _isLoading.value = false
//            if (result is Result.Success) {
//                // Notify success
//            } else if (result is Result.Error) {
//                // Handle error
//            }
//        }
//    }

}