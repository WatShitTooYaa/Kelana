package com.dicoding.storyapp.login

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.dicoding.storyapp.R
import com.dicoding.storyapp.UserModel
import com.dicoding.storyapp.UserPreference
import com.dicoding.storyapp.data.response.LoginResponse
import com.dicoding.storyapp.data.retrofit.ApiConfig
import com.dicoding.storyapp.databinding.ActivityLoginBinding
import com.dicoding.storyapp.story.StoryActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var user: UserModel
    private lateinit var mUserPreference: UserPreference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        mUserPreference = UserPreference(this)

        binding.btnLogin.setOnClickListener { view ->
            val email = binding.loginUserEditText.text.toString().trim()
            val password = binding.loginPassEditText.text.toString().trim()
            postLogin(email, password)
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(view.windowToken, 0)
        }

        binding.loginPassEditText.addTextChangedListener( object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                //
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.btnLogin.isEnabled = s != null && s.length >= 8
            }

            override fun afterTextChanged(s: Editable?) {
                //
            }
        })

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun postLogin(email: String, password: String) {
        showLoading(true)
        val client = ApiConfig.getApiService().postLogin(email, password)
        client.enqueue(object : Callback<LoginResponse> {
            override fun onResponse(call: Call<LoginResponse>, response: Response<LoginResponse>) {
                showLoading(false)
                val responseBody = response.body()
                if (response.isSuccessful && responseBody != null) {
                    user = UserModel()

                    user.name = responseBody.loginResult?.name
                    user.token = responseBody.loginResult?.token
                    user.userId = responseBody.loginResult?.userId

                    mUserPreference.setUser(user)

                    Toast.makeText(this@LoginActivity, "Success", Toast.LENGTH_LONG).show()
                    moveToStory()
                }
                else {
                    Log.e(TAG, "Unauthorized: ${response.message()}")
                    Toast.makeText(this@LoginActivity, "gagal login", Toast.LENGTH_LONG).show()
                }
            }

            override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                showLoading(false)
                Toast.makeText(this@LoginActivity, "message: ${t.message}", Toast.LENGTH_LONG).show()
                Log.e(TAG, "onFailure: ${t.message}")
            }
        })
    }

    private fun showLoading(isLoading: Boolean) {binding.progressBar.visibility = if (isLoading) View.GONE else View.VISIBLE}

    private fun moveToStory() {
        val intent = Intent(this@LoginActivity, StoryActivity::class.java)
        startActivity(intent)
        finish()
    }

    companion object {
        private const val TAG = "loginActivity"
    }
}