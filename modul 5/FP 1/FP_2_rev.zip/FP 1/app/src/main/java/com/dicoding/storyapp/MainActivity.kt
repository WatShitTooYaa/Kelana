package com.dicoding.storyapp

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.dicoding.storyapp.databinding.ActivityMainBinding
import com.dicoding.storyapp.login.LoginActivity
import com.dicoding.storyapp.register.RegisterActivity
import com.dicoding.storyapp.story.StoryActivity

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private lateinit var user: UserModel
    private lateinit var mUserPreference: UserPreference
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnMvLogin.setOnClickListener {
            val intent = Intent(this@MainActivity, LoginActivity::class.java)
            startActivity(intent)
        }

        binding.btnMvRegister.setOnClickListener {
            val intent = Intent(this@MainActivity, RegisterActivity::class.java)
            startActivity(intent)
        }

        mUserPreference = UserPreference(this)

        showExistingPreference()

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun showExistingPreference() {
        user = mUserPreference.getUser()
        if (user.name.toString().isEmpty()) {
            Toast.makeText(this@MainActivity, "Belum ada akun", Toast.LENGTH_SHORT).show()
        }
        else {
            Toast.makeText(this@MainActivity, "user: ${user.name} \n token: ${user.token}", Toast.LENGTH_SHORT).show()
            val intent = Intent(this@MainActivity, StoryActivity::class.java)
            startActivity(intent)
            finish()
        }
    }


}