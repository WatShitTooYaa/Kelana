package com.dicoding.storyapp

import com.dicoding.storyapp.data.response.ListStoryItem

object DataDummy {
    fun generateDummyStoryResponse(): List<ListStoryItem> {
        val items: MutableList<ListStoryItem> = arrayListOf()
        for (i in 0..100) {
            val storyItem = ListStoryItem(
                id = "story-$i-fdXLAehbxMY2",
                name = "dummy",
                description = "desc",
                photoUrl = "https://story-api.dicoding.dev/images/stories/photos-1717422753139_ade697ffd3fb166e991e.jpg",
                createdAt = "2024-06-03T13:52:33.141Z",
                lat = 37.4220133 + (i / 10),
                lon = -122.0840581 - (i / 10)
            )
            items.add(storyItem)
        }
        return items
    }
}